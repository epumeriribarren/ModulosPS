<?php
if(!defined('_PS_VERSION_'))
    exit;
class CreaFeed extends Module {
	public function __construct() {
		$this->name = 'creafeed'; //nombre del módulo el mismo que la carpeta y la clase.
	    $this->tab = 'Catalog'; // pestaña en la que se encuentra en el backoffice.
	    $this->version = '1.0.0'; //versión del módulo
	    $this->author ='Epumer: informatico@barcelonaled.com'; // autor del módulo
	    $this->need_instance = 0; //si no necesita cargar la clase en la página módulos,1 si fuese necesario.
	    $this->ps_versions_compliancy = array('min' => '1.6.x.x', 'max' => _PS_VERSION_); //las versiones con las que el módulo es compatible.
	    $this->bootstrap = true; //si usa bootstrap plantilla responsive.

	    parent::__construct(); //llamada al constructor padre.

	    $this->displayName = $this->l('Crear feed'); // Nombre del módulo
	    $this->description = $this->l('Crea un feed para criteo'); //Descripción del módulo
	    $this->confirmUninstall = $this->l('¿Estás seguro de que quieres desinstalar el módulo?'); //mensaje de alerta al desinstalar el módulo.
	}

	public function install() {
		return parent::install()
			   && $this->installTab('AdminCreaFeed', 'Crear feed', 'Catalog');
	}

	public function uninstall() {
		return parent::uninstall()
			   && $this->uninstallTab('AdminCreaFeed');
	}

	public function installTab($class_name,$tab_name,$tab_parent_name=false) {
	    $tab = new Tab();
	    $tab->active = 1;
	    $tab->class_name = $class_name;
	    $tab->name = array();
	    foreach (Language::getLanguages(true) as $lang)
	        $tab->name[$lang['id_lang']] = $tab_name;
	    if($tab_parent_name) {
	        $tab->id_parent = (int)Tab::getIdFromClassName($tab_parent_name);
	    }else {
	        $tab->id_parent = 0;
	    }
	    $tab->module = $this->name;
	    return $tab->add();
	}

	public function uninstallTab($class_name) {
	    $id_tab = (int)Tab::getIdFromClassName($class_name);
	    if ($id_tab){
	        $tab = new Tab($id_tab);
	        return $tab->delete();
	    }
	    else
	        return false;
	}

	public function getContent()
    {
    	$output = null;
    	if (Tools::isSubmit('submit'.$this->name))
        {
        	$output .= $this->displayConfirmation('Se generó el feed');
        }
        return $output.$this->displayForm();
    }

    public function displayForm()
    {
    	$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $langs = Language::getLanguages();
        $options = array();
        foreach ( $langs as $lang ) {
            $options[] = array(
                'id_lang' => $lang['id_lang'],
                'name' => $lang['name']
            );
        }
        $fields_form = array();
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Crear feed'),
            ),
            'submit' => array(
                'title' => $this->l('Crear'),
                'class' => 'btn btn-default pull-right'
            )
        );
        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;        // false -> remove toolbar
        $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.

        $helper->submit_action = 'submit'.$this->name;
        $helper->toolbar_btn = array(
            'save' => array(
                'desc' => $this->l('Guardar'),
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
                '&token='.Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' => array(
                'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Atras')
            )
        );

        return $helper->generateForm($fields_form);
    }
}

?>