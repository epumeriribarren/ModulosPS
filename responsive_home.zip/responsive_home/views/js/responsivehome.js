if($(document).width()<=444){
	$(".flexslider").css("display","none");
}else{
	$(".flexslider").css("display","block");
}